default_app_config = 'mutant.contrib.related.apps.RelatedConfig'
