from __future__ import unicode_literals

from .utils import HandlerProxy

handler = HandlerProxy()
