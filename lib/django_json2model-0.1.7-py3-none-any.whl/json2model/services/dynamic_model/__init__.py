from json2model.services.dynamic_model.dynamic_data_instances import create_instances_from_json
from json2model.services.dynamic_model.dynamic_model_mutant import (
    create_objects_from_json, get_dynamic_model, delete_all_dynamic_models, delete_dynamic_model,
)
