import logging
from importlib import import_module, reload

from django.conf import settings
from django.contrib import admin
from django.urls import clear_url_caches
from mutant.models import ModelDefinition

ROOT_URLCONF = getattr(settings, 'ROOT_URLCONF')

APP_LABEL = getattr(settings, 'APP_LABEL_DYNAMIC_MODELS', "json2model")

logger = logging.getLogger(__name__)


def register_all_models():
    model_defs = ModelDefinition.objects.filter(app_label=APP_LABEL)
    for model_def in model_defs:
        try_register_model_in_admin(model_def)


def try_register_model_in_admin(model_def):
    ObjectModel = model_def.model_class()
    attrs = {'model': ObjectModel}
    ObjectModelAdmin = type(f'{ObjectModel.__name__}Admin', (admin.ModelAdmin,), attrs)
    try:
        admin.site.register(ObjectModel, ObjectModelAdmin)
        reload_and_clear_cache_admin()
    except admin.sites.AlreadyRegistered:
        logger.debug(f"model_def: {model_def.name}, was already registered in admin.site, "
                     f"and could therefore not register")


def try_unregister_model_in_admin(model_def):
    ObjectModel = model_def.model_class()
    try:
        admin.site.unregister(ObjectModel)
        reload_and_clear_cache_admin()
    except admin.sites.NotRegistered:
        logger.debug(f"model_def: {model_def.name}, was not registered in admin.site, "
                     f"and could therefore not unregister")


def reload_and_clear_cache_admin():
    reload(import_module(ROOT_URLCONF))
    clear_url_caches()
