class FailedObject:
    def __init__(self, object_label, error, data):
        self.object_label = object_label
        self.error = error
        self.data = data
