
import functools
import logging

def create_logger():
    """
    Creates a logging object and returns it
    """
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # # create the logging file handler
    # fh = logging.FileHandler("/path/to/test.log")
    #
    # fmt = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    # formatter = logging.Formatter(fmt)
    # fh.setFormatter(formatter)
    #
    # # add handler to logger object
    # logger.addHandler(fh)
    return logger


def except_errors(function):
    """
    A decorator that wraps the passed in function and logs
    exceptions should one occur
    """
    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        logger = create_logger()
        try:
            return function(*args, **kwargs)
        except:
            # log the exception
            err = "There was an exception in  "
            err += function.__name__
            logger.exception(err)

            # re-raise the exception
            raise
    return wrapper