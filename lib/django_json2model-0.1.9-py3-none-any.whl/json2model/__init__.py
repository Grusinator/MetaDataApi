default_app_config = 'json2model.apps.Json2ModelConfig'
